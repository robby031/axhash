/* tslint:disable */
/* eslint-disable */

export class Hasher {
    free(): void;
    [Symbol.dispose](): void;
    digest(): bigint;
    constructor(seed?: bigint | null);
    reset(seed: bigint): void;
    update(data: Uint8Array): void;
}

export function axhash(data: Uint8Array): bigint;

export function axhash_seeded(data: Uint8Array, seed: bigint): bigint;

export function runtime_backend(): string;

export function runtime_has_aes(): boolean;

export function version(): string;
