/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_hasher_free: (a: number, b: number) => void;
export const axhash: (a: number, b: number) => bigint;
export const axhash_seeded: (a: number, b: number, c: bigint) => bigint;
export const hasher_digest: (a: number) => bigint;
export const hasher_new: (a: number, b: bigint) => number;
export const hasher_reset: (a: number, b: bigint) => void;
export const hasher_update: (a: number, b: number, c: number) => void;
export const runtime_backend: () => [number, number];
export const runtime_has_aes: () => number;
export const version: () => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
