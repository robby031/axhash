/* @ts-self-types="./axhash_wasm.d.ts" */
import * as wasm from "./axhash_wasm_bg.wasm";
import { __wbg_set_wasm } from "./axhash_wasm_bg.js";

__wbg_set_wasm(wasm);
wasm.__wbindgen_start();
export {
    Hasher, axhash, axhash_seeded, runtime_backend, runtime_has_aes, version
} from "./axhash_wasm_bg.js";
